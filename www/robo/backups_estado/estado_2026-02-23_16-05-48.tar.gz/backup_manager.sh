#!/bin/bash

# Configurações de caminhos
ROBO_DIR=$(pwd)
BACKUP_DIR="$ROBO_DIR/backups_estado"
DATA=$(date +'%Y-%m-%d_%H-%M-%S')

mkdir -p "$BACKUP_DIR"

case "$1" in
    save)
        echo "💾 Salvando estado atual do robô..."
        tar -czf "$BACKUP_DIR/estado_$DATA.tar.gz" --exclude='node_modules' --exclude='output' .
        echo "✅ Estado salvo em: $BACKUP_DIR/estado_$DATA.tar.gz"
        ;;
    list)
        echo "📂 Backups disponíveis:"
        ls -lh "$BACKUP_DIR"
        ;;
    *)
        echo "Uso: ./backup_manager.sh {save|list}"
        ;;
esac
