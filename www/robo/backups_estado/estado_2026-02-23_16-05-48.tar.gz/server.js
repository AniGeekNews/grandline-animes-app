import express from 'express';
import bodyParser from 'body-parser';
import fs from 'fs-extra';
import path from 'path';
import { fileURLToPath } from 'url';
import readline from 'readline';

const app = express();
const PORT = 3000;
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PROJETO_RAIZ = path.resolve(__dirname, '../../');
const OUTPUT_DIR = path.join(__dirname, 'output');

// Função para criar a pergunta no terminal
const perguntar = (query) => {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    return new Promise(resolve => rl.question(query, ans => {
        rl.close();
        resolve(ans.toLowerCase());
    }));
};

app.use(bodyParser.json({ limit: '50mb' }));
app.use(express.static('.'));

app.post('/api/salvar-arquivos', async (req, res) => {
    const { vFS } = req.body;
    console.log("\n==========================================");
    console.log("📥 VERIFICAÇÃO DE LOTE RECEBIDA");
    console.log("==========================================");

    let listaParaTransferir = [];

    // Primeiro, apenas montamos a lista para te mostrar
    for (const editorId in vFS) {
        for (const subfolder in vFS[editorId].subfolders) {
            let pastaProducao = "";
            if (subfolder === "secoes") pastaProducao = "secoes";
            else if (subfolder === "estilos/secoes") pastaProducao = path.join("estilos", "secoes");
            else if (subfolder === "scripts") pastaProducao = "scripts";

            const realPath = path.join(PROJETO_RAIZ, editorId, pastaProducao);

            for (const file of vFS[editorId].subfolders[subfolder]) {
                listaParaTransferir.push({
                    editor: editorId.toUpperCase(),
                    arquivo: file.name,
                    destino: realPath,
                    conteudo: file.content,
                    backup: path.join(OUTPUT_DIR, editorId, subfolder, file.name)
                });
                console.log(`📄 ARQUIVO: ${file.name}`);
                console.log(`   📍 DESTINO: ${realPath}\n`);
            }
        }
    }

    console.log(`📊 Total de arquivos: ${listaParaTransferir.length}`);
    
    // A MÁGICA ACONTECE AQUI: O Servidor para e espera você
    const resposta = await perguntar("🤔 Confirmar transferência para as pastas acima? (sim/não): ");

    if (resposta === 'sim' || resposta === 's') {
        try {
            for (const item of listaParaTransferir) {
                // 1. Grava Backup
                await fs.ensureDir(path.dirname(item.backup));
                await fs.writeFile(item.backup, item.conteudo);

                // 2. Grava na Produção
                if (await fs.pathExists(path.dirname(item.destino).split(path.sep).slice(0, -1).join(path.sep))) {
                    await fs.ensureDir(item.destino);
                    await fs.writeFile(path.join(item.destino, item.arquivo), item.conteudo);
                    console.log(`✅ EFETUADO: ${item.editor} -> ${item.arquivo}`);
                }
            }
            console.log("\n✨ Sincronização concluída com sucesso!");
            res.json({ success: true, message: "Aprovado e enviado!" });
        } catch (err) {
            console.log("🚨 ERRO:", err.message);
            res.status(500).json({ success: false });
        }
    } else {
        console.log("\n❌ OPERAÇÃO CANCELADA PELO USUÁRIO.");
        res.json({ success: false, message: "Transferência negada." });
    }
});

app.listen(PORT, () => {
    console.log(`\n🤖 MODO SEGURO ATIVADO`);
    console.log(`🚀 Aguardando comando do navegador na porta ${PORT}...`);
});
